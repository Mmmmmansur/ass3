public class Main {
    public static void main(String[] args) {
        MP4Player mp4Player = new MP4Player();
        MediaConverter mp4ToMP3Converter = new MP4ToMP3Adapter(mp4Player);

        String mp4File = "Hypnotize.mp4";
        String mp3File = "C:\\Users\\Мансур\\ass3\\src\\Hypnotize.mp3";

        mp4ToMP3Converter.convert(mp4File, mp3File);
    }
}