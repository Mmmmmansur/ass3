public class MP4Player {
    public void playMP4(String fileName) {
        System.out.println("Playing MP4: " + fileName);
    }
}
