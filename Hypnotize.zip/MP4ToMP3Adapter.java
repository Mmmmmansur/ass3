public class MP4ToMP3Adapter implements MediaConverter {
    private MP4Player mp4Player;

    public MP4ToMP3Adapter(MP4Player mp4Player) {
        this.mp4Player = mp4Player;
    }

    @Override
    public void convert(String sourceFileName, String destinationFileName) {
        System.out.println("Converting MP4 to MP3...");
        mp4Player.playMP4(sourceFileName);
        System.out.println("Converted to MP3: " + destinationFileName);
    }
}
