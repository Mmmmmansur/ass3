public interface MediaConverter {
    void convert(String sourceFileName, String destinationFileName);
}